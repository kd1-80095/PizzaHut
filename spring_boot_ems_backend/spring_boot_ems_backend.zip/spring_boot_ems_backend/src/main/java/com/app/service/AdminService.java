package com.app.service;

import com.app.dto.SignUp;

public interface AdminService {

	SignUp adminRegistration(SignUp reqDTO);
}
